//
//  ModeloDatos.swift
//  TableViewGrouped
//
//  Created by mbtec22 on 5/20/20.
//  Copyright © 2020 Tecsup. All rights reserved.
//

import UIKit

class ModeloDatos{
    
    func obtenerSeccionesDesdeDatos() -> [Secciones] {
        
        var seccionesArray = [Secciones]()
        
        let peliculas = Secciones(titulo: "Titulos de Películas", objetos: ["Infinity War","Freddy vs Jason","Titanic","La maldición de Chucky","Pixeles"])
        let actores = Secciones(titulo: "Actores", objetos: ["Robert Englund","Ken Kirzinger","Robert Downey Jr."])
        
        let ciudades = Secciones(titulo: "Ciudades", objetos: ["Los Angeles","New York"])
        
        seccionesArray.append(peliculas)
        
        seccionesArray.append(actores)
        
        seccionesArray.append(ciudades)
        
        return seccionesArray
    }

}
